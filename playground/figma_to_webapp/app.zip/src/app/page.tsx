export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Component Gallery
          </h1>
          <p className="text-xl text-gray-600">
            A collection of beautiful, reusable UI components
          </p>
        </div>
        
        <div className="grid gap-8">
          {/* Card Component */}
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Product Card</h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg p-6 border border-blue-200">
                <div className="w-16 h-16 bg-blue-500 rounded-lg mb-4"></div>
                <h3 className="font-semibold text-gray-800 mb-2">Premium Plan</h3>
                <p className="text-gray-600 text-sm mb-4">Everything you need for professional projects</p>
                <div className="text-2xl font-bold text-blue-600 mb-4">$29/mo</div>
                <button className="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors">
                  Get Started
                </button>
              </div>
              
              <div className="bg-gradient-to-br from-purple-50 to-pink-100 rounded-lg p-6 border border-purple-200">
                <div className="w-16 h-16 bg-purple-500 rounded-lg mb-4"></div>
                <h3 className="font-semibold text-gray-800 mb-2">Pro Plan</h3>
                <p className="text-gray-600 text-sm mb-4">Advanced features for growing teams</p>
                <div className="text-2xl font-bold text-purple-600 mb-4">$59/mo</div>
                <button className="w-full bg-purple-500 text-white py-2 px-4 rounded-lg hover:bg-purple-600 transition-colors">
                  Get Started
                </button>
              </div>
              
              <div className="bg-gradient-to-br from-green-50 to-emerald-100 rounded-lg p-6 border border-green-200">
                <div className="w-16 h-16 bg-green-500 rounded-lg mb-4"></div>
                <h3 className="font-semibold text-gray-800 mb-2">Enterprise</h3>
                <p className="text-gray-600 text-sm mb-4">Custom solutions for large organizations</p>
                <div className="text-2xl font-bold text-green-600 mb-4">Custom</div>
                <button className="w-full bg-green-500 text-white py-2 px-4 rounded-lg hover:bg-green-600 transition-colors">
                  Contact Sales
                </button>
              </div>
            </div>
          </div>
          
          {/* Dashboard Component */}
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">Dashboard Overview</h2>
            <div className="grid md:grid-cols-4 gap-4 mb-8">
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">2,847</div>
                <div className="text-sm text-gray-600">Total Users</div>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-green-600">$42,892</div>
                <div className="text-sm text-gray-600">Revenue</div>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">168</div>
                <div className="text-sm text-gray-600">Active Projects</div>
              </div>
              <div className="bg-orange-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-orange-600">94%</div>
                <div className="text-sm text-gray-600">Performance</div>
              </div>
            </div>
            
            <div className="h-64 bg-gradient-to-r from-blue-100 to-purple-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <div className="text-4xl mb-2">📊</div>
                <div className="text-gray-600">Chart Component Placeholder</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}